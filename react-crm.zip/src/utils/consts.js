const API_URL = "https://mint-bunny-weekly.ngrok-free.app/v1";

export { API_URL };
